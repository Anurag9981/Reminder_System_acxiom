"use client"
import '@/app/css/employeauth.css'
import Create from '@/Components/home/Create'
import Footer from '@/Components/home/Footer'
import Show from '@/Components/home/Show'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

const page = () => {
  const dispatch = useDispatch()
  const { employe } = useSelector((state)=>state.EmployeReducer)
  const [title, settitle] = useState("")
  const [description, setdescription] = useState("")
  const [status, setstatus] = useState("Due")
  const [tasks, settasks] = useState([])
  const [activetask, setactivetask] = useState(null)
  useEffect(()=>{
  },[employe])
  return <>
    
    <div>
      <Create
        title = {title}
        settitle = {settitle}
        description = {description}
        setdescription = {setdescription}
        status = {status}
        setstatus = {setstatus}
        tasks = {tasks}
        settasks = {settasks}
        activetask = {activetask}
        setactivetask = {setactivetask}

      />
      <hr />
      <h2 className='ms-5'>Tasks</h2>
      <Show 
      tasks = {tasks}
      settasks = {settasks}
      setdescription = {setdescription}
      setstatus = {setstatus}
      setactivetask = {setactivetask}
      settitle = {settitle}
      activetask = {activetask}
      />
    </div>

  <Footer />
  </>
}

export default page